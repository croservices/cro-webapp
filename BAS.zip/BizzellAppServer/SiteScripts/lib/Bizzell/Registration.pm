use 5.004;

use strict;
use warnings;

package Bizzell::Registration;

use DBI;
use DateTime;
use Data::Dumper;
use Exporter;
use Socket;
use vars qw(@ISA @EXPORT @EXPORT_OK);

use constant CHARS     => 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
use constant MINCHARS  => 6;
use constant MAXCHARS  => 18;
use constant COLLECTOR => 'automaton.thebizzellgroup.com';

@ISA = qw(Exporter);

BEGIN {
  @EXPORT    = qw(
    &openDB
    &closeDB
    &openSiteDB
    &closeSiteDB
    &getSiteURL
    &createDatabase
    &inputPrompt
    &fluentform1
    &gravityform1
  );

  @EXPORT_OK = qw(
    &openDB
    &closeDB
    &openSiteDB
    &closeSiteDB
    &getSiteURL
    &createDatabase
    &fluentform1
    &gravityform1
    &updateCounts
    &inputPrompt
  );
}

my $LIMIT = 90;
my ($dbh, $siteDbh);

sub inputPrompt {
  my ($prompt, $default) = @_;

  print $prompt;
  print " [$default]" if defined($default);
  print ": ";
  my $input = <STDIN>;
  chomp($input);
  if ( defined($default) && !length($input) ) {
    $input = $default;
  }

  return $input;
}

sub openDB {
  my ($params) = @_;

  print $params->{'dsn'}, "\n";

  $dbh = DBI->connect(
    $params->{'dsn'},
    $params->{'user'},
    $params->{'password'}
  );
}

sub closeDB {
  $dbh->disconnect;
}

sub openSiteDB {
  my ($params) = @_;

  print $params->{'wp-dsn'}, "\n";

  $siteDbh = DBI->connect(
    $params->{'wp-dsn'},
    $params->{'user'},
    $params->{'password'}
  );
}

sub getSiteURL {
  my $sth = $siteDbh->prepare(<<'SQL');
SELECT option_value
FROM   wp_options
WHERE  option_name = 'siteurl'
SQL

  $sth->execute();
  return $sth->rows() ? $sth->fetchall_arrayref()->[0][0] : '';
}

sub closeSiteDB {
  $siteDbh->disconnect;
}

sub createRandomPassword {
  my $chars = int(rand(MAXCHARS - MINCHARS)) + MINCHARS;

  my $p = '';
  $p .= substr(CHARS, int( rand(length(CHARS)) ), 1) for 0..$chars;
  $p;
}

sub createDatabase {
  my ($dsn, $user, $password, $drop) = @_;
  $drop = 0 unless defined($drop);

  openDB({
    dsn      => $dsn,
    user     => $user,
    password => $password
  });
  $dbh->do('DROP DATABASE bizzell_registration') if $drop;
  $dbh->do('CREATE DATABASE bizzell_registration');
  #$dbh->do('CONNECT bizzell_registration');
  $dbh->do(<<'SQL');
CREATE TABLE `bizzell_registration`.`counts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `name` varchar(128) NOT NULL,
  `count` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_counts_date` (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
SQL

  my $pw = createRandomPassword();
  $dbh->do('DROP USER bizzellReg@localhost') if $drop;

  my $collectorIP = inet_ntoa(inet_aton(COLLECTOR))
    or die "Can't resolve collector IP!";

  for ('localhost', $collectorIP) {
    $dbh->do("CREATE USER bizzellReg\@$_ IDENTIFIED BY '" . $pw . '\';' );
    if $_ ne 'localhost' {
      $dbh->do("GRANT SELECT on bizzell_registration.* to bizzellReg\@$_");
      next;
    }
    $dbh->do('GRANT ALL on bizzell_registration.* to bizzellReg@localhost');
    $dbh->do('GRANT SELECT ON bitnami_wordpress.* TO bizzellReg@localhost');
  }

  return {
    dsn      => 'dbi:mysql:bizzell_registration:localhost:3306',
    user     => 'bizzellReg',
    password => $pw
  };
}

sub grabByDate {
  my ($table, $column) = @_;

  my $sth = $siteDbh->prepare(<<"SQL");
SELECT DATE($column) AS day, count(*) AS count
FROM $table
GROUP BY DATE($column)
ORDER BY DATE($column) DESC
LIMIT $LIMIT
SQL

  $sth->execute();
  $sth->fetchall_arrayref({});
}

sub fluentform1 {
  my ($name) = @_;

  for ( @{ grabByDate('wp_fluentform_submissions', 'created_at') } ) {
    updateCounts($name, $_->{'day'}, $_->{'count'})
  }
}

sub gravityform1 {
  my ($name) = @_;

  for ( @{ grabByDate('wp_gf_entry', 'date_created') } ) {
    updateCounts($name, $_->{'day'}, $_->{'count'})
  }
}

sub updateCounts {
  my ($name, $date, $count) = @_;

  my $sth = $dbh->prepare(<<'SQL');
SELECT id
FROM counts
WHERE date = ? AND name = ?
SQL

  $sth->execute($date, $name);
  my ($r, $id) = ($sth->fetchall_arrayref(), '');

  $id = $r->[0][0] if $sth->rows;
  if ($id) {
    $sth = $dbh->prepare(<<'SQL');
UPDATE counts
SET count = ?
WHERE id = ?
SQL

    $sth->execute($count, $id);
  } else {
    $sth = $dbh->prepare(<<'SQL');
INSERT INTO counts (date, name, count) VALUES (?, ?, ?)
SQL

    $sth->execute($date, $name, $count);
  }

}

1;
