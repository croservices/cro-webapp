use strict;
use warnings;

package Bizzell::Config;

use Exporter;
use vars qw(@ISA @EXPORT @EXPORT_OK);

@ISA = qw(Exporter);

BEGIN {
  @EXPORT    = qw(&readWPConfig &readConfig &getAmazonAPI);

  @EXPORT_OK = qw(
    &readWPConfig
    &readConfig
    &getAmazonAPI
  );
}

sub fileSlurp {
  my ($filename) = @_;
  local $/ = undef;
  open my $fh, '<', $filename
    or die "Could not open configuration file '$filename': $!";
  <$fh>
}

sub readWPConfig {
  my ($wpConfigFile) = @_;
  $wpConfigFile = '/opt/bitnami/apps/wordpress/htdocs/wp-config.php'
    unless defined($wpConfigFile);

  return {} unless -e $wpConfigFile;

  my %wpConfig;
  my $wpConfigData = fileSlurp($wpConfigFile);
  if ($wpConfigData     =~ /'DB_NAME',\s*'(.+?)'/) {
    $wpConfig{'database'} = $1;
  }
  if ($wpConfigData     =~ /'DB_USER',\s*'(.+?)'/) {
    $wpConfig{'user'} = $1;
  }
  if ($wpConfigData =~ /'DB_PASSWORD',\s*'(.+?)'/) {
    $wpConfig{'password'} = $1;
  }
  if ($wpConfigData     =~ /'DB_HOST',\s*'(.+?)'/) {
    $wpConfig{'host'} = $1;
  }

  return \%wpConfig;
}

sub readConfig {
  my ($configFile) = @_;

  # Read in config file
  my $config = fileSlurp($configFile);

  # Parse config file
  my $Config = { };
  for (split "\n", $config) {
    my ($name, $value) = split(/\s*=\s*/, $_);
    $Config->{ lc($name) } = $value;
  }

  die "Config file must specify URL"           unless $Config->{'url'};
  die "Config file must specify DSN"           unless $Config->{'dsn'};
  die "Config file must speficy Wordpress DSN" unless $Config->{'wp-dsn'};
  die "Config file must specify User"          unless $Config->{'user'};
  die "Config file must specify Counters"      unless $Config->{'counters'};

  return $Config;
}

sub getAmazonAPI {
  #my $l = split( /\n/, fileSlurp($ENV{'HOME'} . '/.ec2/default.csv') );
  my $file  = fileSlurp($ENV{'HOME'} . '/.ec2/default.csv');
  my @lines = split(/\n/, $file);
  my @d     = split(/\s*,\s*/, $lines[1]);

  return Net::Amazon::EC2->new(
    AWSAccessKeyId    => $d[2],
    SecretAccessKey   => $d[3],
    signature_version => 4
  );
}

1;
