sudo apt install cpanminus
sudo cpanm Getopt::Long HTTP::Request LWP::UserAgent::JSON URI::Encode Config::Crontab Data::Dumper DBI DBD::mysql

