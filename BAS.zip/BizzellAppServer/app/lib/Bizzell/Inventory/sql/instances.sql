CREATE TABLE `instances` (
  `instance-id` varchar(64) NOT NULL,
  `public-hostname` varchar(255) NOT NULL,
  `instance-type` varchar(64) NOT NULL,
  `availability-zone` varchar(32) NOT NULL,
  `name` varchar(128) NOT NULL,
  `public-keys` varchar(128) NOT NULL,
  `total-disk` bigint NOT NULL DEFAULT '0',
  `free-disk` bigint NOT NULL,
  `public-ip` varchar(32) NOT NULL,
  `last-updated` datetime DEFAULT NULL,
  `login-user` varchar(64) NOT NULL,
  PRIMARY KEY (`instance-id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci
