CREATE TABLE `audit_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `column` varchar(64) NOT NULL,
  `old_value` varchar(64) DEFAULT NULL,
  `change_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `table` varchar(64) NOT NULL,
  `instance-id` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci
