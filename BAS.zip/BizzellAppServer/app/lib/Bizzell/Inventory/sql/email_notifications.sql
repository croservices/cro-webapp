CREATE TABLE `email_notifications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `instance-id` varchar(64) DEFAULT NULL,
  `email-addresses` varchar(96) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci
