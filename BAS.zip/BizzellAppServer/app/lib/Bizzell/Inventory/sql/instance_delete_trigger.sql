DELIMITER $$

DROP TRIGGER IF EXISTS after_inventory_delete;

CREATE TRIGGER after_inventory_delete
AFTER DELETE
ON instances FOR EACH ROW
BEGIN
  INSERT INTO audit_log (`table`, `instance-id`, `column`, old_value)
  VALUES ('instances', OLD.`instance-id`, 'DELETE', 'ROW DELETED');

  DELETE FROM thresholds WHERE `instance-id` = OLD.`instance-id`;
  
  DELETE FROM email_notifications WHERE `instance-id` = OLD.`instance-id`;
END$$

DELIMITER ;
