DELIMITER $$

DROP TRIGGER IF EXISTS after_inventory_update;

CREATE TRIGGER after_inventory_update
AFTER UPDATE
ON instances FOR EACH ROW
BEGIN
  IF OLD.`public-hostname` <> NEW.`public-hostname` THEN
    INSERT INTO audit_log (`instance-id`, `table`, `column`, old_value)
    VALUES (OLD.`instance-id`, 'instances', 'public-hostname', OLD.`public-hostname`);
  END IF;

  IF OLD.`instance-type` <> new.`instance-type` THEN
    INSERT INTO audit_log (`instance-id`, `table`, `column`, old_value)
    VALUES (OLD.`instance-id`, 'instances', 'instance-type', old.`instance-type`);
  END IF;

  IF OLD.`availability-zone` <> new.`availability-zone` THEN
    INSERT INTO audit_log (`instance-id`, `table`, `column`, old_value)
    VALUES (OLD.`instance-id`, 'instances', 'availability-zone', old.`availability-zone`);
  END IF;

  IF OLD.`name` <> new.`name` THEN
    INSERT INTO audit_log (`instance-id`, `table`, `column`, old_value)
    VALUES (OLD.`instance-id`, 'instances', 'name', old.`name`);
  END IF;

  IF OLD.`total-disk` <> new.`total-disk` THEN
    INSERT INTO audit_log (`instance-id`, `table`, `column`, old_value)
    VALUES (OLD.`instance-id`, 'instances', 'total-disk', old.`total-disk`);
  END IF;

  IF OLD.`free-disk` <> new.`free-disk` THEN
    INSERT INTO audit_log (`instance-id`, `table`, `column`, old_value)
    VALUES (OLD.`instance-id`, 'instances', 'free-disk', old.`free-disk`);
  END IF;

  IF OLD.`public-ip` <> new.`public-ip` THEN
    INSERT INTO audit_log (`instance-id`, `table`, `column`, old_value)
    VALUES (OLD.`instance-id`, 'instances', 'public-ip', old.`public-ip`);
  END IF;

  IF OLD.`login-user` <> new.`login-user` THEN
    INSERT INTO audit_log (`instance-id`, `table`, `column`, old_value)
    VALUES (OLD.`instance-id`, 'instances', 'login-user', old.`login-user`);
  END IF;
END$$

DELIMITER ;
