#!/bin/bash
CRO_DEV=1 raku --stagestats -Ilib -I ~/Other_Projects/cro-webapp/lib "$@"
